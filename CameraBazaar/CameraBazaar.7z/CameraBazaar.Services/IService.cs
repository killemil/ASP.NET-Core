﻿namespace CameraBazaar.Services
{
    public interface IService
    {
    }
}
