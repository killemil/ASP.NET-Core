﻿namespace CameraBazaar.Data.Models.Enums
{
    public enum MinISO
    {
        ISO50 = 50,
        ISO100 = 100
    }
}
