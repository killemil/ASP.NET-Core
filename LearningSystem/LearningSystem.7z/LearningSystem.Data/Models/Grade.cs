﻿namespace LearningSystem.Data.Models
{
    public enum Grade
    {
        A = 0,
        B = 1,
        C = 2,
        D = 3,
        E = 4,
        F = 5
    }
}
