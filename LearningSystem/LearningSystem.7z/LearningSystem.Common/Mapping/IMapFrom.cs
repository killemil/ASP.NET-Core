﻿namespace LearningSystem.Common.Mapping
{
    public interface IMapFrom <TModel>
    {
    }
}