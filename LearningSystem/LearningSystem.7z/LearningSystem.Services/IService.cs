﻿namespace LearningSystem.Services
{
    public interface IService
    {
    }
}
