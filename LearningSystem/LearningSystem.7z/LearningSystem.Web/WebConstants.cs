﻿namespace LearningSystem.Web
{
    public class WebConstants
    {
        public const string AdminRole = "Admin";

        public const string Student = "Student";

        public const string Trainer = "Trainer";

        public const string BlogAuthor = "BlogAuthor";
    }
}
